# Каталоги Agent Skills

Ссылки проверены 19 ноября 2026 года. Ищи по задаче, а совместимость и условия использования проверяй по исходнику конкретного навыка.

## Официальные источники

- OpenAI публикует актуальные примеры для Codex в `openai/plugins`. У пакетов с навыками ищи папку `skills/`. Исторический `openai/skills` помечен устаревшим и перенаправляет читателя в новый репозиторий. [OpenAI Plugins](https://github.com/openai/plugins/tree/main/plugins) · [Прежний каталог](https://github.com/openai/skills)
- Anthropic публикует примеры навыков для документов, таблиц, презентаций и других рабочих задач. Лицензию смотри в папке нужного навыка. [Anthropic Skills](https://github.com/anthropics/skills/tree/main/skills)

## Крупные индексы

- Ищи популярные навыки, свежие поступления и варианты установки для разных агентов, включая Codex. [Skills.sh](https://www.skills.sh/)
- Ищи по задаче или категории среди навыков из публичных репозиториев GitHub. [SkillsMP](https://skillsmp.com/)
- Смотри результаты автоматического сканирования как дополнительный сигнал. На карточках есть просмотр инструкции и ссылки на исходник. Скачивание ZIP через сайт может требовать Pro. [Skills Directory](https://www.skillsdirectory.com/skills)
- Смотри содержимое `SKILL.md` и заявленную совместимость с агентами прямо в карточках. [mdskills.ai](https://www.mdskills.ai/skills)

## Авторские и редакционные подборки

- Обзор литературы, анализ данных, визуализация и научное письмо. Коллекция K-Dense под MIT. [Scientific Agent Skills](https://github.com/k-dense-ai/scientific-agent-skills#-available-skills)
- Практика разработки с разборами применения. Уточнение требований, спецификации, ревью кода и диагностика ошибок. [AI Hero — Matt Pocock](https://www.aihero.dev/skills-catalog)
- Маркетинговые исследования, аналитика, SEO, тексты и оптимизация конверсии. Коллекция под MIT. [Marketing Skills](https://marketing-skills.com/skills)
- Редакционная подборка по разным темам с опубликованными критериями включения и сведениями об авторе и обновлениях. [AgenticSkills](https://agenticskills.io/skills) · [Методика отбора](https://agenticskills.io/methodology)

## Поиск первоисточников

Exa можно использовать, если этот поиск доступен в текущей среде. Подойдёт и доступный веб-поиск. [Exa](https://exa.ai/)
